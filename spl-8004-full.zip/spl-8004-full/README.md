# spl-8004 (SPL-8004) - Anchor example project

This repository contains a full Anchor program and a minimal TypeScript client to demonstrate the SPL-8004 concept (AgentIdentity / Validation / Reputation) on Solana.

**How to use (localdev)**

1. Install prerequisites:
   - Rust, Cargo, Anchor CLI, Node.js, npm, solana-cli
2. Ensure Rust toolchain updated:
   ```bash
   rustup update stable
   ```
3. Start local validator (optional):
   ```bash
   solana-test-validator --reset
   ```
4. Build program:
   ```bash
   anchor build
   ```
5. Deploy (localnet):
   ```bash
   anchor deploy
   ```
6. Run client:
   ```bash
   cd client
   npm install
   cp .env.example .env
   # edit .env then
   npm run start
   ```
