# Client
Copy .env.example to .env and edit PROGRAM_ID and ANCHOR_PROVIDER_URL if needed.
npm install
npm run start
