import * as anchor from "@project-serum/anchor";
import { Keypair, PublicKey, SystemProgram } from "@solana/web3.js";
import * as dotenv from "dotenv";
dotenv.config();

const PROGRAM_ID = new PublicKey(process.env.PROGRAM_ID || "Strun1111111111111111111111111111111111111");
const provider = anchor.AnchorProvider.local(process.env.ANCHOR_PROVIDER_URL || "http://localhost:8899");
anchor.setProvider(provider);
const idl = JSON.parse(require('../../target/idl/strun_program.json'));
const program = new anchor.Program(idl, PROGRAM_ID, provider);

async function initializeRegistry() {
  const [registryPda] = await PublicKey.findProgramAddress([Buffer.from("registry")], PROGRAM_ID);
  const tx = await program.methods.initializeRegistry().accounts({
    registry: registryPda,
    admin: provider.wallet.publicKey,
    systemProgram: SystemProgram.programId
  }).rpc();
  console.log("initializeRegistry tx:", tx);
}

async function createAgent(name: string, metadataUri: string) {
  const [registryPda] = await PublicKey.findProgramAddress([Buffer.from("registry")], PROGRAM_ID);
  const registryAccount: any = await program.account.registry.fetch(registryPda);
  const agentId = registryAccount.agentCount.toNumber();
  const [agentPda] = await PublicKey.findProgramAddress([Buffer.from("agent"), registryPda.toBuffer(), Buffer.from(new anchor.BN(agentId).toArray("le", 8))], PROGRAM_ID);

  const tx = await program.methods.createAgent(name, metadataUri).accounts({
    registry: registryPda,
    agent: agentPda,
    owner: provider.wallet.publicKey,
    payer: provider.wallet.publicKey,
    systemProgram: SystemProgram.programId
  }).rpc();
  console.log("createAgent tx:", tx);
  console.log("agentPda:", agentPda.toBase58());
}

async function main() {
  console.log("Provider:", provider.connection.rpcEndpoint);
  // await initializeRegistry();
  // await createAgent("Runny", "ipfs://runny-meta");
}

main().catch(console.error);
