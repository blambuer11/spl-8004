
use anchor_lang::prelude::*;

declare_id!("Strun1111111111111111111111111111111111111");

#[program]
pub mod strun_program {
    use super::*;

    pub fn initialize_registry(ctx: Context<InitializeRegistry>) -> Result<()> {
        let registry = &mut ctx.accounts.registry;
        registry.agent_count = 0;
        registry.validation_count = 0;
        registry.admin = *ctx.accounts.admin.key;
        Ok(())
    }

    pub fn create_agent(
        ctx: Context<CreateAgent>,
        name: String,
        metadata_uri: String,
    ) -> Result<()> {
        let registry = &mut ctx.accounts.registry;

        // use current counter as id (first agent id == 0)
        let agent_id = registry.agent_count;

        let agent = &mut ctx.accounts.agent;
        agent.agent_id = agent_id;
        agent.owner = *ctx.accounts.owner.key;
        agent.name = name;
        agent.metadata_uri = metadata_uri;
        agent.created_at = Clock::get()?.unix_timestamp;

        // increment counter after PDA derived using current counter
        registry.agent_count = registry.agent_count.checked_add(1).ok_or(ErrorCode::CounterOverflow)?;

        emit!(AgentCreated {
            agent_id,
            owner: agent.owner,
            name: agent.name.clone(),
            metadata_uri: agent.metadata_uri.clone(),
            created_at: agent.created_at
        });

        Ok(())
    }

    pub fn update_agent_metadata(
        ctx: Context<UpdateAgentMetadata>,
        name: Option<String>,
        metadata_uri: Option<String>,
    ) -> Result<()> {
        let agent = &mut ctx.accounts.agent;
        let registry = &ctx.accounts.registry;

        let auth = ctx.accounts.authority.key();
        if auth != &agent.owner && auth != &registry.admin {
            return err!(ErrorCode::Unauthorized);
        }

        if let Some(n) = name {
            agent.name = n;
        }
        if let Some(m) = metadata_uri {
            agent.metadata_uri = m;
        }

        emit!(AgentMetadataUpdated {
            agent_id: agent.agent_id,
            name: agent.name.clone(),
            metadata_uri: agent.metadata_uri.clone()
        });

        Ok(())
    }

    pub fn add_validation(
        ctx: Context<AddValidation>,
        task_hash: [u8; 32],
        agent_id: u64,
        passed: bool,
        proof_uri: String,
        notes: String,
    ) -> Result<()> {
        let registry = &mut ctx.accounts.registry;

        let validation_id = registry.validation_count;

        let validation = &mut ctx.accounts.validation;
        validation.validation_id = validation_id;
        validation.task_hash = task_hash;
        validation.agent_id = agent_id;
        validation.validator = *ctx.accounts.validator.key;
        validation.passed = passed;
        validation.proof_uri = proof_uri;
        validation.notes = notes;
        validation.timestamp = Clock::get()?.unix_timestamp;

        registry.validation_count = registry.validation_count.checked_add(1).ok_or(ErrorCode::CounterOverflow)?;

        emit!(ValidationAdded {
            validation_id,
            task_hash,
            agent_id,
            validator: validation.validator,
            passed
        });

        Ok(())
    }

    pub fn revoke_validation(ctx: Context<RevokeValidation>) -> Result<()> {
        let registry = &ctx.accounts.registry;
        if *ctx.accounts.admin.key != registry.admin {
            return err!(ErrorCode::Unauthorized);
        }

        let validation = &mut ctx.accounts.validation;
        validation.passed = false;
        validation.notes = format!("REVOKED: {}", validation.notes);
        emit!(ValidationRevoked {
            validation_id: validation.validation_id,
            task_hash: validation.task_hash
        });
        Ok(())
    }

    pub fn init_reputation(ctx: Context<InitReputation>) -> Result<()> {
        let rep = &mut ctx.accounts.reputation;
        rep.agent_id = ctx.accounts.agent.agent_id;
        rep.score = 0;
        rep.reviews = 0;
        rep.last_updated = Clock::get()?.unix_timestamp;
        Ok(())
    }

    pub fn update_reputation(ctx: Context<UpdateReputation>, delta: i64) -> Result<()> {
        let rep = &mut ctx.accounts.reputation;
        rep.score = rep.score.checked_add(delta).ok_or(ErrorCode::MathOverflow)?;
        rep.reviews = rep.reviews.checked_add(1).ok_or(ErrorCode::CounterOverflow)?;
        rep.last_updated = Clock::get()?.unix_timestamp;

        emit!(ReputationUpdated {
            agent_id: rep.agent_id,
            new_score: rep.score,
            reviews: rep.reviews
        });

        Ok(())
    }
}

/// Events
#[event]
pub struct AgentCreated {
    pub agent_id: u64,
    pub owner: Pubkey,
    pub name: String,
    pub metadata_uri: String,
    pub created_at: i64,
}

#[event]
pub struct AgentMetadataUpdated {
    pub agent_id: u64,
    pub name: String,
    pub metadata_uri: String,
}

#[event]
pub struct ValidationAdded {
    pub validation_id: u64,
    pub task_hash: [u8; 32],
    pub agent_id: u64,
    pub validator: Pubkey,
    pub passed: bool,
}

#[event]
pub struct ValidationRevoked {
    pub validation_id: u64,
    pub task_hash: [u8; 32],
}

#[event]
pub struct ReputationUpdated {
    pub agent_id: u64,
    pub new_score: i64,
    pub reviews: u64,
}

/// Accounts and sizes

#[account]
pub struct Registry {
    pub admin: Pubkey,
    pub agent_count: u64,
    pub validation_count: u64,
}
impl Registry { pub const LEN: usize = 32 + 8 + 8; }

#[account]
pub struct AgentAccount {
    pub agent_id: u64,
    pub owner: Pubkey,
    pub name: String,        // 4 + max 64
    pub metadata_uri: String,// 4 + max 256
    pub created_at: i64,
}
impl AgentAccount { pub const LEN: usize = 8 + 32 + 4 + 64 + 4 + 256 + 8; }

#[account]
pub struct ValidationAccount {
    pub validation_id: u64,
    pub task_hash: [u8; 32],
    pub agent_id: u64,
    pub validator: Pubkey,
    pub passed: bool,
    pub proof_uri: String, // 4 + 512
    pub notes: String,     // 4 + 256
    pub timestamp: i64,
}
impl ValidationAccount {
    pub const LEN: usize = 8 + 32 + 8 + 32 + 1 + 4 + 512 + 4 + 256 + 8;
}

#[account]
pub struct ReputationAccount {
    pub agent_id: u64,
    pub score: i64,
    pub reviews: u64,
    pub last_updated: i64,
}
impl ReputationAccount { pub const LEN: usize = 8 + 8 + 8 + 8; }

/// Contexts

#[derive(Accounts)]
pub struct InitializeRegistry<'info> {
    #[account(init, payer = admin, space = 8 + Registry::LEN, seeds = [b"registry"], bump)]
    pub registry: Account<'info, Registry>,
    #[account(mut)]
    pub admin: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(name: String, metadata_uri: String)]
pub struct CreateAgent<'info> {
    #[account(mut, seeds = [b"registry"], bump)]
    pub registry: Account<'info, Registry>,

    #[account(
        init,
        payer = payer,
        space = 8 + AgentAccount::LEN,
        seeds = [b"agent", registry.key().as_ref(), &registry.agent_count.to_le_bytes()],
        bump
    )]
    pub agent: Account<'info, AgentAccount>,

    /// owner of the agent
    pub owner: UncheckedAccount<'info>,

    #[account(mut)]
    pub payer: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdateAgentMetadata<'info> {
    #[account(mut, seeds = [b"agent", registry.key().as_ref(), &agent.agent_id.to_le_bytes()], bump)]
    pub agent: Account<'info, AgentAccount>,

    #[account(mut, seeds = [b"registry"], bump)]
    pub registry: Account<'info, Registry>,

    #[account(signer)]
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
#[instruction(task_hash: [u8;32], agent_id: u64)]
pub struct AddValidation<'info> {
    #[account(mut, seeds = [b"registry"], bump)]
    pub registry: Account<'info, Registry>,

    #[account(
        init,
        payer = validator,
        space = 8 + ValidationAccount::LEN,
        seeds = [b"validation", registry.key().as_ref(), &registry.validation_count.to_le_bytes()],
        bump
    )]
    pub validation: Account<'info, ValidationAccount>,

    #[account(mut)]
    pub validator: Signer<'info>,

    #[account(mut, seeds = [b"agent", registry.key().as_ref(), &agent_id.to_le_bytes()], bump)]
    pub agent: Account<'info, AgentAccount>,

    #[account(mut)]
    pub payer: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RevokeValidation<'info> {
    #[account(mut, seeds = [b"registry"], bump)]
    pub registry: Account<'info, Registry>,

    #[account(mut, seeds = [b"validation", registry.key().as_ref(), &validation.validation_id.to_le_bytes()], bump)]
    pub validation: Account<'info, ValidationAccount>,

    #[account(signer)]
    pub admin: Signer<'info>,
}

#[derive(Accounts)]
pub struct InitReputation<'info> {
    #[account(mut, seeds = [b"registry"], bump)]
    pub registry: Account<'info, Registry>,

    #[account(mut, seeds = [b"agent", registry.key().as_ref(), &agent.agent_id.to_le_bytes()], bump)]
    pub agent: Account<'info, AgentAccount>,

    #[account(
        init,
        payer = payer,
        space = 8 + ReputationAccount::LEN,
        seeds = [b"reputation", registry.key().as_ref(), &agent.agent_id.to_le_bytes()],
        bump
    )]
    pub reputation: Account<'info, ReputationAccount>,

    #[account(mut)]
    pub payer: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdateReputation<'info> {
    #[account(mut, seeds = [b"registry"], bump)]
    pub registry: Account<'info, Registry>,

    #[account(mut, seeds = [b"reputation", registry.key().as_ref(), &reputation.agent_id.to_le_bytes()], bump)]
    pub reputation: Account<'info, ReputationAccount>,

    #[account(signer)]
    pub updater: Signer<'info>,
}

/// Errors
#[error_code]
pub enum ErrorCode {
    #[msg("Counter overflow")]
    CounterOverflow,
    #[msg("Math overflow")]
    MathOverflow,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Not found")]
    NotFound,
}
