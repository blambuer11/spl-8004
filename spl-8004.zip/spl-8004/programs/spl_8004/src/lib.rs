use anchor_lang::prelude::*;

declare_id!("8o04sPL1111111111111111111111111111111111111");

#[program]
pub mod spl_8004 {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        let state = &mut ctx.accounts.state;
        state.authority = *ctx.accounts.authority.key;
        Ok(())
    }

    pub fn verify_task(ctx: Context<VerifyTask>, proof: String) -> Result<()> {
        let task = &mut ctx.accounts.task;
        task.proof = proof;
        task.verified = true;
        Ok(())
    }
}

#[account]
pub struct State {
    pub authority: Pubkey,
}

#[account]
pub struct Task {
    pub proof: String,
    pub verified: bool,
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(init, payer = authority, space = 8 + 32)]
    pub state: Account<'info, State>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct VerifyTask<'info> {
    #[account(mut)]
    pub task: Account<'info, Task>,
    pub authority: Signer<'info>,
}
